package com.shpp.p2p.cs.ezhuk.assignment14;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class Archiver {

    private static final String path = "src/com/shpp/p2p/cs/ezhuk/assignment14/files/";

    private HashMap<Byte,Byte> map = new HashMap<>();

    Archiver(boolean isArchive, String inFileName, String outFileName) {
        byte[] file = readFile(inFileName);
        if (isArchive) {
            long workTime = System.currentTimeMillis();
            byte[] archive = archive(file);
            System.out.printf("File size %19d\n", file.length);
            System.out.printf("Archive size %16d\n", archive.length);
            System.out.printf("Compression efficiency%6s%.3f\n", " ", (float) file.length / archive.length);
            writeFile(archive, outFileName);
            System.out.printf("Archiving time = %10s %.3f", " ", (System.currentTimeMillis() - workTime) / 1000.0);
        }
        if (!isArchive) {
            long workTime = System.currentTimeMillis();
            byte[] unArchive = unArchive(file);
            System.out.printf("File size %19d\n", file.length);
            System.out.printf("Archive size %16d\n", unArchive.length);
            System.out.printf("Decompression efficiency%4s%.3f\n", " ", (float) unArchive.length / file.length);
            writeFile(unArchive, outFileName);
            System.out.printf("Unarchiving time %10s %.3f\n", " ", (System.currentTimeMillis() - workTime) / 1000.0);
        }
    }

    private byte[] archive(byte[] byteFile) {
        int wordLength = getWordLength(byteFile);
        ArrayList<Byte> archive = new ArrayList<>();
        StringBuilder binaryWord = new StringBuilder();
        for (byte b : byteFile) {
//            System.out.println(b + " | " + Integer.toBinaryString(map.get(b)));
            binaryWord.append(addStr(map.get(b), wordLength));
//            System.out.println(binaryWord);
            if (binaryWord.length() >= 8) {
//                System.out.println("parse = " + binaryWord.substring(0, 8));
                archive.add(myParseByte(binaryWord.substring(0, 8)));
                binaryWord.delete(0, 8);
            }
        }
        int lastByteLength = 0;
        if (binaryWord.length() > 0) {
            lastByteLength = binaryWord.length();
            archive.add(Byte.parseByte(binaryWord.toString(), 2));
//            System.out.println("lastByteLength = " + lastByteLength);
        }

//        System.out.println("oldByte len = " + byteFile.length);
//        System.out.println("newByte len = " + archive.size());
        System.out.printf("Map size %20d\n", map.size());
        return createArray(archive, wordLength, lastByteLength);
    }

    private byte[] unArchive(byte[] file) {
        ArrayList<Byte> unArchive = new ArrayList<>();
        int mapSize = (byteToUnsignedInt(file[0]) + 1) * 2;
        int wordLength = byteToUnsignedInt(file[1]);
        int lastByteLength = byteToUnsignedInt(file[2]);
//        System.out.println(" key |  val " + mapSize);
        for (int i = 0; i < mapSize; i += 2) {
//            System.out.printf("%4d | %4d\n", file[i + 4], file[i + 3]);
            map.put(file[i + 4], file[i + 3]);
        }
//        System.out.println();
        StringBuilder binaryWord = new StringBuilder();
        for (int i = mapSize + 3; i < file.length; i++) {
            if (i == file.length - 1  && lastByteLength > 0) {
                binaryWord.append(addStr(file[i], lastByteLength));
            } else {
                binaryWord.append(addStr(file[i], 8));
            }
//            System.out.println(i);
//            System.out.println(binaryWord);
            while (binaryWord.length() >= wordLength) {
                String byteStr = binaryWord.substring(0, wordLength);
//                System.out.println("parse = " + binaryWord.substring(0, wordLength) + " " + Byte.parseByte(byteStr,2));
                binaryWord.delete(0, wordLength);
                if (byteStr.length() == 8 && byteStr.charAt(0) == '1') {
                    unArchive.add(map.get(myParseByte(byteStr)));
//                    System.out.println(map.get(myParseByte(byteStr)));
                }
                else {
                    unArchive.add(map.get( (byte) Integer.parseInt(byteStr,2)));
//                    System.out.println(map.get( (byte) Integer.parseInt(byteStr,2)) + " " + (byte) Integer.parseInt(byteStr,2));
                }
//                System.out.println(map.get(myParseByte(byteStr)) + " " + myParseByte(byteStr));
            }

        }
        return byteArrayListToArray(unArchive);
    }
//    private String parseSignedByte(byte b) {
//        String result = Integer.toBinaryString(b);
//        if (result.length() > 8) result = result.substring(result.length() - 8);
//        return result;

//    }

    private int byteToUnsignedInt(byte b) {
//        System.out.println(b);
        String byteStr = Integer.toBinaryString(b);
//        System.out.println(byteStr);
        if (byteStr.length() >= 8) byteStr = byteStr.substring(byteStr.length() - 8);
//        System.out.println(byteStr);
        return Integer.parseInt(byteStr,2);
    }

    private byte myParseByte(String binaryWord) {
//        System.out.println("myParseByteBinaryWord:" + binaryWord);
        byte result = Byte.parseByte(binaryWord.substring(1),2);
//        System.out.println("myParseByteResult:" + result);
        if (binaryWord.length() == 8 && binaryWord.charAt(0) == '1') {
            result -= 128;
        }
//        System.out.println("myParseByteResult:" + result);
        return result;
    }

    private String addStr(byte b, int wordLength) {
//        System.out.println(b);
        String byteStr = Integer.toBinaryString(b);
//        System.out.println("addStr:" + byteStr);
        if (byteStr.length() > 8) byteStr = byteStr.substring(byteStr.length() - 8);
//        System.out.println("addStr:" + byteStr);
        if (byteStr.length() < wordLength) {
//            System.out.println("byteStrBefore:" + byteStr);
            byteStr = String.format("%0" + wordLength + "d", Integer.parseInt(byteStr));
//            System.out.println("byteStrAfter:" + byteStr);
        }
//        System.out.println(b + " " + byteStr);
        return byteStr;
    }

    private byte[] createArray(ArrayList<Byte> archive, int wordLength, int lastByteLength) {
//        System.out.println("createArray");
        for (Map.Entry<Byte,Byte> e : map.entrySet()) {
            archive.add(0,e.getValue());
            archive.add(0,e.getKey());
        }

        archive.add(0, (byte) lastByteLength);
        archive.add(0, (byte) wordLength);
//        System.out.println("getMapSize = " + getMapSize());
        archive.add(0, getMapSize());

        return byteArrayListToArray(archive);
    }

    private byte[] byteArrayListToArray(ArrayList<Byte> arrayList) {
//        System.out.println("fileSize = " + arrayList.size());
        byte[] result = new byte[arrayList.size()];
        for (int i = 0; i < result.length; i++) {
//            System.out.println(arrayList.get(i));
            result[i] = arrayList.get(i);
        }
        return result;
    }

    private byte getMapSize() {
        String mapSize = Integer.toBinaryString(map.size() - 1);
//        System.out.println(mapSize);
        if (mapSize.length() < 8) return Byte.parseByte(mapSize,2);
        else {
            byte b = Byte.parseByte(mapSize.substring(1),2);
            b -= 128;
            return b;
        }
    }

    private int getWordLength(byte[] bytes) {
        ArrayList<Byte> byteArrayList = new ArrayList<>();
        for (byte aByte : bytes)
            if (!byteArrayList.contains(aByte)) byteArrayList.add(aByte);
        double len = Math.log(byteArrayList.size()) / Math.log(2);
        if (len / (int) len != 1) len = ((int) len) + 1;
        System.out.printf("Unique bytes %16d\nWord length %17d\n",byteArrayList.size(),(int)len);

        byte counter = 0;
        for (byte b : byteArrayList) {
            map.put(b,counter);
//            System.out.println("k:"+b+"v:"+counter);
            counter++;
        }

//        System.out.println(" key | val");
//        for (Map.Entry<Byte,Byte> e : map.entrySet()) {
//            System.out.printf("%4s | %4s\n", e.getKey(), e.getValue());
//        }


        return (int) len;
    }

    private byte[] readFile(String filename) {
        try {
            System.out.println("Path: " + Paths.get(path + filename));
            return Files.readAllBytes(Paths.get(path + filename));
        } catch (Exception e) {
            System.out.println("Can't read file");
            System.exit(-1);
            return null;
        }
    }

    private void writeFile(byte[] file, String outFileName) {
        try (FileOutputStream outputStream = new FileOutputStream(path + outFileName)) {
            outputStream.write(file);
        } catch (IOException e) {
            System.out.println("Can't write file\nPath: " + (path + outFileName));
        }
    }

}
